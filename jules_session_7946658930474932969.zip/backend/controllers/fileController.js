const File = require('../models/File');

exports.uploadFile = async (req, res) => {
  try {
    const newFile = new File({
      filename: req.file.originalname,
      path: req.file.path,
      uploader: req.user.id,
    });

    const file = await newFile.save();
    res.json(file);
  } catch (err) {
    console.error(err.message);
    res.status(500).send('Server Error');
  }
};

exports.getPendingFiles = async (req, res) => {
  try {
    const files = await File.find({ status: 'pending' });
    res.json(files);
  } catch (err) {
    console.error(err.message);
    res.status(500).send('Server Error');
  }
};

exports.approveFile = async (req, res) => {
  try {
    let file = await File.findById(req.params.id);
    if (!file) {
      return res.status(404).json({ msg: 'File not found' });
    }

    file.status = 'approved';
    file.approvedBy = req.user.id;
    await file.save();
    res.json(file);
  } catch (err) {
    console.error(err.message);
    res.status(500).send('Server Error');
  }
};

exports.disapproveFile = async (req, res) => {
  try {
    let file = await File.findById(req.params.id);
    if (!file) {
      return res.status(404).json({ msg: 'File not found' });
    }

    file.status = 'disapproved';
    file.disapprovedBy = req.user.id;
    file.disapprovalComment = req.body.comment;
    await file.save();
    res.json(file);
  } catch (err) {
    console.error(err.message);
    res.status(500).send('Server Error');
  }
};

exports.getMyFiles = async (req, res) => {
  try {
    const files = await File.find({ uploader: req.user.id });
    res.json(files);
  } catch (err) {
    console.error(err.message);
    res.status(500).send('Server Error');
  }
};
