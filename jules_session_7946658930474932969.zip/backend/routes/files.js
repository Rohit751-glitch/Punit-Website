const express = require('express');
const router = express.Router();
const multer = require('multer');
const auth = require('../middleware/auth');
const fileController = require('../controllers/fileController');

// Multer configuration
const storage = multer.diskStorage({
  destination: function (req, file, cb) {
    cb(null, 'backend/uploads/');
  },
  filename: function (req, file, cb) {
    cb(null, Date.now() + '-' + file.originalname);
  },
});

const upload = multer({ storage: storage });

// @route   POST api/files/upload
// @desc    Upload file
// @access  Private
router.post('/upload', [auth, upload.single('file')], fileController.uploadFile);

// @route   GET api/files/myfiles
// @desc    Get my files
// @access  Private
router.get('/myfiles', auth, fileController.getMyFiles);

// HOD Routes
const hod = require('../middleware/hod');

// @route   GET api/files/pending
// @desc    Get all pending files
// @access  HOD
router.get('/pending', [auth, hod], fileController.getPendingFiles);

// @route   PUT api/files/approve/:id
// @desc    Approve a file
// @access  HOD
router.put('/approve/:id', [auth, hod], fileController.approveFile);

// @route   PUT api/files/disapprove/:id
// @desc    Disapprove a file
// @access  HOD
router.put('/disapprove/:id', [auth, hod], fileController.disapproveFile);

module.exports = router;
