const express = require('express');
const router = express.Router();
const auth = require('../middleware/auth');
const userController = require('../controllers/userController');

// @route   GET api/users/me
// @desc    Get current user's info
// @access  Private
router.get('/me', auth, userController.getMe);

// Admin Routes
const admin = require('../middleware/admin');

// @route   GET api/users
// @desc    Get all users
// @access  Admin
router.get('/', [auth, admin], userController.getUsers);

// @route   POST api/users
// @desc    Create a user
// @access  Admin
router.post('/', [auth, admin], userController.createUser);

// @route   PUT api/users/:id/status
// @desc    Activate/deactivate a user
// @access  Admin
router.put('/:id/status', [auth, admin], userController.updateUserStatus);

// @route   PUT api/users/:id/password
// @desc    Reset a user's password
// @access  Admin
router.put('/:id/password', [auth, admin], userController.resetUserPassword);


module.exports = router;
