import React, { useState, useEffect } from 'react';
import fileService from '../services/fileService';
import './HodDashboard.css';

const HodDashboard = () => {
  const [files, setFiles] = useState([]);
  const [message, setMessage] = useState('');

  useEffect(() => {
    fileService.getPendingFiles().then(
      (response) => {
        setFiles(response.data);
      },
      (error) => {
        const resMessage =
          (error.response &&
            error.response.data &&
            error.response.data.msg) ||
          error.message ||
          error.toString();
        setMessage(resMessage);
      }
    );
  }, []);

  const handleApprove = (id) => {
    fileService.approveFile(id).then(
      () => {
        setFiles(files.filter((file) => file._id !== id));
        setMessage('File approved successfully');
      },
      (error) => {
        const resMessage =
          (error.response &&
            error.response.data &&
            error.response.data.msg) ||
          error.message ||
          error.toString();
        setMessage(resMessage);
      }
    );
  };

  const handleDisapprove = (id) => {
    const comment = prompt('Enter a reason for disapproval:');
    if (comment) {
      fileService.disapproveFile(id, comment).then(
        () => {
          setFiles(files.filter((file) => file._id !== id));
          setMessage('File disapproved successfully');
        },
        (error) => {
          const resMessage =
            (error.response &&
              error.response.data &&
              error.response.data.msg) ||
            error.message ||
            error.toString();
          setMessage(resMessage);
        }
      );
    }
  };

  return (
    <div className="dashboard-container">
      <h1>HOD Dashboard</h1>
      {message && <p>{message}</p>}
      <div className="file-list">
        <h3>Pending Files</h3>
        <ul>
          {files.map((file) => (
            <li key={file._id} className="file-item">
              <span>{file.filename}</span>
              <div className="actions">
                <button onClick={() => handleApprove(file._id)}>Approve</button>
                <button onClick={() => handleDisapprove(file._id)}>
                  Disapprove
                </button>
              </div>
            </li>
          ))}
        </ul>
      </div>
    </div>
  );
};

export default HodDashboard;
