import React, { useState, useEffect } from 'react';
import fileService from '../services/fileService';
import './UserDashboard.css';

const UserDashboard = () => {
  const [files, setFiles] = useState([]);
  const [selectedFile, setSelectedFile] = useState(null);
  const [message, setMessage] = useState('');

  useEffect(() => {
    fileService.getMyFiles().then(
      (response) => {
        setFiles(response.data);
      },
      (error) => {
        const resMessage =
          (error.response &&
            error.response.data &&
            error.response.data.msg) ||
          error.message ||
          error.toString();
        setMessage(resMessage);
      }
    );
  }, []);

  const handleFileChange = (event) => {
    setSelectedFile(event.target.files[0]);
  };

  const handleUpload = (e) => {
    e.preventDefault();
    setMessage('');

    fileService.uploadFile(selectedFile).then(
      (response) => {
        setFiles([...files, response.data]);
        setMessage('File uploaded successfully');
      },
      (error) => {
        const resMessage =
          (error.response &&
            error.response.data &&
            error.response.data.msg) ||
          error.message ||
          error.toString();
        setMessage(resMessage);
      }
    );
  };

  return (
    <div className="dashboard-container">
      <h1>User Dashboard</h1>
      <div className="upload-form">
        <h3>Upload File</h3>
        <form onSubmit={handleUpload}>
          <input type="file" onChange={handleFileChange} />
          <button type="submit">Upload</button>
        </form>
        {message && <p>{message}</p>}
      </div>
      <div className="file-list">
        <h3>My Files</h3>
        <ul>
          {files.map((file) => (
            <li key={file._id} className="file-item">
              <span>{file.filename}</span>
              <span>{file.status}</span>
            </li>
          ))}
        </ul>
      </div>
    </div>
  );
};

export default UserDashboard;
