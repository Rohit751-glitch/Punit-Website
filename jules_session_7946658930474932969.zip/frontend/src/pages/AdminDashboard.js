import React, { useState, useEffect } from 'react';
import userService from '../services/userService';
import './AdminDashboard.css';

const AdminDashboard = () => {
  const [users, setUsers] = useState([]);
  const [username, setUsername] = useState('');
  const [password, setPassword] = useState('');
  const [role, setRole] = useState('User');
  const [message, setMessage] = useState('');

  useEffect(() => {
    userService.getUsers().then(
      (response) => {
        setUsers(response.data);
      },
      (error) => {
        const resMessage =
          (error.response &&
            error.response.data &&
            error.response.data.msg) ||
          error.message ||
          error.toString();
        setMessage(resMessage);
      }
    );
  }, []);

  const handleCreateUser = (e) => {
    e.preventDefault();
    setMessage('');

    userService.createUser(username, password, role).then(
      (response) => {
        setUsers([...users, response.data]);
        setMessage('User created successfully');
      },
      (error) => {
        const resMessage =
          (error.response &&
            error.response.data &&
            error.response.data.msg) ||
          error.message ||
          error.toString();
        setMessage(resMessage);
      }
    );
  };

  const handleStatusUpdate = (id, isActive) => {
    userService.updateUserStatus(id, isActive).then(
      () => {
        setUsers(
          users.map((user) =>
            user._id === id ? { ...user, isActive } : user
          )
        );
      },
      (error) => {
        const resMessage =
          (error.response &&
            error.response.data &&
            error.response.data.msg) ||
          error.message ||
          error.toString();
        setMessage(resMessage);
      }
    );
  };

  const handlePasswordReset = (id) => {
    const newPassword = prompt('Enter a new password:');
    if (newPassword) {
      userService.resetUserPassword(id, newPassword).then(
        () => {
          setMessage('Password reset successfully');
        },
        (error) => {
          const resMessage =
            (error.response &&
              error.response.data &&
              error.response.data.msg) ||
            error.message ||
            error.toString();
          setMessage(resMessage);
        }
      );
    }
  };

  return (
    <div className="dashboard-container">
      <h1>Admin Dashboard</h1>
      {message && <p>{message}</p>}
      <div className="create-user-form">
        <h3>Create User</h3>
        <form onSubmit={handleCreateUser}>
          <input
            type="text"
            placeholder="Username"
            value={username}
            onChange={(e) => setUsername(e.target.value)}
            required
          />
          <input
            type="password"
            placeholder="Password"
            value={password}
            onChange={(e) => setPassword(e.target.value)}
            required
          />
          <select value={role} onChange={(e) => setRole(e.target.value)}>
            <option value="User">User</option>
            <option value="HOD">HOD</option>
            <option value="Admin">Admin</option>
          </select>
          <button type="submit">Create User</button>
        </form>
      </div>
      <div className="user-list">
        <h3>All Users</h3>
        <ul>
          {users.map((user) => (
            <li key={user._id} className="user-item">
              <span>{user.username}</span>
              <span>{user.role}</span>
              <span>{user.isActive ? 'Active' : 'Inactive'}</span>
              <div className="actions">
                <button
                  onClick={() => handleStatusUpdate(user._id, !user.isActive)}
                >
                  {user.isActive ? 'Deactivate' : 'Activate'}
                </button>
                <button onClick={() => handlePasswordReset(user._id)}>
                  Reset Password
                </button>
              </div>
            </li>
          ))}
        </ul>
      </div>
    </div>
  );
};

export default AdminDashboard;
