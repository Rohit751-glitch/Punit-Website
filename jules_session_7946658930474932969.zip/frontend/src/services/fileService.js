import axios from 'axios';
import authHeader from './authHeader';

const API_URL = '/api/files/';

const uploadFile = (file) => {
  let formData = new FormData();
  formData.append('file', file);

  return axios.post(API_URL + 'upload', formData, {
    headers: {
      ...authHeader(),
      'Content-Type': 'multipart/form-data',
    },
  });
};

const getMyFiles = () => {
  return axios.get(API_URL + 'myfiles', { headers: authHeader() });
};

const getPendingFiles = () => {
  return axios.get(API_URL + 'pending', { headers: authHeader() });
};

const approveFile = (id) => {
  return axios.put(API_URL + `approve/${id}`, {}, { headers: authHeader() });
};

const disapproveFile = (id, comment) => {
  return axios.put(
    API_URL + `disapprove/${id}`,
    { comment },
    { headers: authHeader() }
  );
};

const fileService = {
  uploadFile,
  getMyFiles,
  getPendingFiles,
  approveFile,
  disapproveFile,
};

export default fileService;
