import axios from 'axios';
import authHeader from './authHeader';

const API_URL = '/api/users/';

const getUserBoard = () => {
  return axios.get(API_URL + 'me', { headers: authHeader() });
};

const getHodBoard = () => {
    // This will be implemented later
    return;
};

const getAdminBoard = () => {
    // This will be implemented later
    return;
};

const getUsers = () => {
  return axios.get(API_URL, { headers: authHeader() });
};

const createUser = (username, password, role) => {
  return axios.post(
    API_URL,
    { username, password, role },
    { headers: authHeader() }
  );
};

const updateUserStatus = (id, isActive) => {
  return axios.put(
    API_URL + `${id}/status`,
    { isActive },
    { headers: authHeader() }
  );
};

const resetUserPassword = (id, password) => {
  return axios.put(
    API_URL + `${id}/password`,
    { password },
    { headers: authHeader() }
  );
};

const userService = {
  getUserBoard,
  getHodBoard,
  getAdminBoard,
  getUsers,
  createUser,
  updateUserStatus,
  resetUserPassword,
};

export default userService;
