import React, { useState, useEffect } from 'react';
import { BrowserRouter as Router, Route, Routes, Link, Navigate } from 'react-router-dom';
import Header from './components/Header';
import Footer from './components/Footer';
import LoginPage from './pages/LoginPage';
import UserDashboard from './pages/UserDashboard';
import HodDashboard from './pages/HodDashboard';
import AdminDashboard from './pages/AdminDashboard';
import PrivateRoute from './components/PrivateRoute';
import authService from './services/authService';
import './App.css';

function App() {
  const [currentUser, setCurrentUser] = useState(undefined);

  useEffect(() => {
    const user = authService.getCurrentUser();

    if (user) {
      setCurrentUser(user);
    }
  }, []);

  const logOut = () => {
    authService.logout();
  };

  const getDashboard = () => {
    if (!currentUser) {
      return <Navigate to="/login" />;
    }
    switch (currentUser.role) {
      case 'Admin':
        return <AdminDashboard />;
      case 'HOD':
        return <HodDashboard />;
      default:
        return <UserDashboard />;
    }
  };

  return (
    <Router>
      <div className="App">
        <Header currentUser={currentUser} logOut={logOut} />
        <main>
          <Routes>
            <Route path="/" element={getDashboard()} />
            <Route path="/login" element={<LoginPage />} />
            <Route
              path="/dashboard"
              element={<PrivateRoute>{getDashboard()}</PrivateRoute>}
            />
          </Routes>
        </main>
        <Footer />
      </div>
    </Router>
  );
}

export default App;
