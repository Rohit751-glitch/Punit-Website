import React from 'react';
import { Link } from 'react-router-dom';

const Header = ({ currentUser, logOut }) => {
  return (
    <header>
      <h1>File Management System</h1>
      <nav>
        {currentUser ? (
          <div>
            <Link to="/dashboard">Dashboard</Link>
            <a href="/login" onClick={logOut}>
              Logout
            </a>
          </div>
        ) : (
          <div>
            <Link to="/login">Login</Link>
          </div>
        )}
      </nav>
    </header>
  );
};

export default Header;
